function save_var_parfor2( p, cm, cm_init )
save(p, 'cm', 'cm_init');
end

