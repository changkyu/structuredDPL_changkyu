function save_var_parfor1( p, cm )
save(p, 'cm');
end
